/** An instance represents a connection between two people in the Network.
 * It is no really used at the moment, so it could be replaced by Object.
 * It is here in case extra behavior is added that might need it.
 * @author Mshnik
 */
public class PersonConnection {}
